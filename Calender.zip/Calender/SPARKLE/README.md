# SPARKLE
Command-line program using python that helps users keep track of events on their calendar

# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import datetime 
import sqlite3
conn = sqlite3.connect('calender.db')
c = conn.cursor()
c.execute("create table if not exists events(eventId INTEGER PRIMARY KEY ,name vachar, date text, event_type vachar)")
conn.row_factory = sqlite3.Row
class Event(object):
	"""docstring for ClassName"""

	def __init__(self,name="",date="",event_type=""):
		self.name = name
		self.event_type  = event_type
		self.date = date
		if name == "" or date  == "" or event_type == "":
			pass
		



	def add_event(self):	
		c.execute("insert into events(name,date,event_type) Values (?,?,?)",(self.name,self.event_type,self.date))
		conn.commit()


	def list_events(self):
		c.execute("select * from events")
		events = c.fetchall()
		for i in events:
			for x in  i:
					print(str(i[0]))					
					print("Event name: "+str(i[1]))
					print("Event date: "+str(i[2]))
					print("Event type: "+str(i[3]))
					print("----------------------")
					break;				


	def drop_event(self):
		c.execute("delete from events")
		conn.commit()

	def last_event(self):
		c.execute("select * from events order by eventId desc")
		events = c.fetchone()
		print(str(events[0]))
		print("Event name: "+str(events[1]))
		print("Event date: "+str(events[2]))
		print("Event type: "+str(events[3]))
		print("----------------------")	

# event = Event('josiah','12.23.23','education')
# event.add_event()

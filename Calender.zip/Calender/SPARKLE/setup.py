from distutils.core import setup
setup(
    name='Sparkle',
    description='Command-line program using python'
                'that helps users keep track of events on their calendar',
    author='BC10 Team Jimmy',
    author_email='suubidavid@gmail.com',
    url='https://github.com/Awesome94/SPARKLE',
    version='1.0.0'
)

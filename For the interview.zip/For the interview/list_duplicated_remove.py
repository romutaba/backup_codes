def remove_duplicates(data):
    n = set(data)
    data = list(n)
    return data

print remove_duplicates([1,2,5,2,1,5])

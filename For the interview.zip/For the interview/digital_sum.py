## printing digital sum
def digital_sum(n):
    print sum([int(char) for char in str(n)]);

digital_sum(12345)

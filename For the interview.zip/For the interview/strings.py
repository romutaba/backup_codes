#splitting strings
a = "this is a string"
a = a.split(" ")
print a

'''join strings'''
a = "-".join(a)
print a
